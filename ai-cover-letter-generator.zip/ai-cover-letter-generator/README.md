# Letterhead — AI Cover Letter Generator

A small SaaS utility that takes a candidate's name, target role, target company,
and key skills, and produces a tailored cover letter — either instantly from a
template (no API call) or generated live by the Google Gemini API.

## Sprint status

| Phase | Scope | Status |
|---|---|---|
| Phase 1 (P0) | Form + client-side template simulation + Copy to Clipboard | ✅ Done |
| Phase 2 (P1) | Real Gemini API integration, key hidden server-side, loading state | ✅ Done |
| Phase 3 (P2) | Resume PDF upload + extraction | Not built yet — see "Next steps" |

## Architecture

This is **not** a single static HTML file, on purpose. Phase 2 requires the
Gemini API key to be genuinely hidden — a key placed anywhere in client-side
JavaScript (even loaded from a `.env` at build time) is visible to anyone who
opens DevTools. So the app is split in two:

- **`public/index.html`** — the entire frontend: one file, no framework, no
  build step. Handles the form, the instant-template mode, the "Generating…"
  state, rendering, and Copy to Clipboard.
- **`server.js`** — a small Express server. It serves `public/` as static
  files *and* exposes one endpoint, `POST /api/generate-cover-letter`, which
  is the only thing that ever talks to Gemini. Your API key lives only in
  `.env` on the server and is never sent to the browser.

```
Browser (index.html) --POST /api/generate-cover-letter--> Express server --> Gemini API
                                                              (key lives here only)
```

## Setup

```bash
npm install
cp .env.example .env
```

Edit `.env` and add your key:

```
GEMINI_API_KEY=your_real_key_here
```

Get a free key at https://aistudio.google.com/apikey (no credit card needed
for the free tier). Then run:

```bash
npm start
```

Open http://localhost:3000. Toggle **Generation mode** to "Gemini AI" to hit
the real API; leave it on "Draft" to use the instant, offline template.

## Security checklist (for the CI/grading check)

- `.env` is listed in `.gitignore` — never committed.
- `.env.example` is committed instead, with a placeholder value.
- The API key is read only inside `server.js` via `process.env.GEMINI_API_KEY`
  and is never sent to or referenced by any file under `public/`.
- Before committing, double-check with `git status` that `.env` doesn't show
  up as a tracked/staged file.

## Notes on the prompt engineering (Phase 2)

The server builds a prompt from the four form fields and sends it to Gemini
with a `system_instruction` that fixes the tone (professional career-coach
voice) and output format (plain paragraphs, no bracket placeholders, no
markdown headers). See `Prompts.md` for the exact prompts used while building
this project.

## Input handling / basic hardening

- Field lengths are capped server-side (name/role/company ≤120 chars, skills
  ≤500 chars) before they're interpolated into the Gemini prompt.
- The frontend escapes all text (user input and the AI's response) before it
  ever touches `innerHTML`, then only re-introduces a small, safe allow-list
  (`**bold**`, paragraph breaks) — so neither a malicious form entry nor an
  unexpected AI response can inject HTML/script into the page.

## Deployment

This app needs a **Node-capable host**, not a static host — a plain Netlify
or GitHub Pages deploy (static-only) will serve `index.html` but the
`/api/generate-cover-letter` route won't exist, so Gemini mode will fail.
Options that work as-is:

- **Render** or **Railway** (free tier): connect the GitHub repo, set the
  `GEMINI_API_KEY` environment variable in their dashboard, done.
- **Netlify functions**: possible, but would need `server.js` restructured
  into a serverless function — a bigger change than a plain deploy.

## Next steps (Phase 3, not built in this pass)

- Add an "Upload Resume" dropzone on the frontend.
- Parse the PDF server-side (e.g. with `pdf-parse`) so the raw file never
  needs to be handled in the browser.
- Append extracted resume text to the Gemini prompt for deeper
  personalization, with the same length-capping approach used for the other
  fields.
