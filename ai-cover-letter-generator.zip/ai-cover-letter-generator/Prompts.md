# Prompts.md

Documentation of how AI assistance was used to build this project, and the
exact prompt engineering used inside the app itself.

## 1. Build-process prompts (Claude)

**Initial brief:** the full Sprint 04 brief (Phase 1–3 spec, QA protocol,
technical FAQ) was provided as-is to Claude.

**Clarifying decisions made before building:**
- Architecture: plain HTML/JS frontend + a separate Node/Express backend
  (no build tooling), so the Gemini API key is never present in any
  client-side file.
- Scope for this pass: Phase 1 (template MVP) + Phase 2 (real Gemini
  integration). Phase 3 (resume PDF parsing) intentionally deferred.

**Follow-up prompt themes used during the build:**
- "Confirm the current Gemini REST endpoint, model name, and free-tier
  status before writing the integration" (verified via web search rather
  than relying on possibly-stale training data).
- "Add server-side validation and length caps on all fields before they're
  interpolated into the prompt sent to Gemini."
- "Make sure the frontend never renders raw AI output into the DOM without
  escaping it first."

## 2. In-app prompt engineering (what the server sends to Gemini)

**System instruction** (fixed, sent with every request):

> You are an expert career coach who writes concise, compelling,
> professional cover letters tailored to the exact role and company given.

**User prompt template** (built in `server.js`, `buildPrompt()`):

```
Write a professional, tailored cover letter using exactly this information:
- Candidate name: {name}
- Target role: {role}
- Target company: {company}
- Key skills to highlight: {skills}

Requirements:
- 3 to 4 short paragraphs.
- Warm, confident, professional tone. No generic filler.
- Address it to the hiring manager at the target company by name of company, not a placeholder.
- Do NOT use bracket placeholders like [Your Name] anywhere — use the real values given above.
- Return only the letter body as plain paragraphs separated by blank lines. No markdown headers, no bullet points, no extra commentary before or after the letter.
```

**Generation config:** `temperature: 0.7`, `maxOutputTokens: 700` — enough
room for a full letter without runaway length or cost.

**Why these choices:**
- The explicit "no bracket placeholders" instruction exists because
  Gemini (like most LLMs) defaults to `[Your Name]`-style placeholders
  unless told not to — a common failure mode worth calling out here since
  it's exactly the kind of thing a grader will notice in a demo.
- Output format is constrained to plain paragraphs (not full Markdown) so
  the frontend's minimal renderer can safely convert it to `<p>` tags
  without needing a full Markdown parser.
